drop schema ToysGroup;
create schema ToysGroup_Jhia_hussein;


drop table prodotti;
create table prodotti (
id_prodotto int primary key unique not null,
nome varchar(10) not null,
prezzo decimal,
categoria varchar(15));



insert into prodotti(id_prodotto,nome,prezzo,categoria)
values(
1,'scacchi',10,'strategia'),
(2,'phase10',15,'strategia'),
(3,'barbie',20,'bambini'),
(4,'kikko',18,'bambini'),
(5,'fattoria',22,'bambini'),
(6,'auto',25,'bambini'),
(7,'orsetto',13,'bambini'),
(8,'dama',8,'strategia'),
(9,'batt_nav',18,'strategia'),
(10,'stratego',24,'strategia'),
(11,'monopoly',30,'strategia'),
(12,'playst',100,'svago'),
(13,'xbox',200,'svago'),
(14,'wii',150,'svago'),
(15,'nintendo',130,'svago'),
(16,'psp',150,'svaglo');

-- select	* from prodotti;

-- drop table regione;
create table regione(
id_regione int primary key ,
nome varchar(10) not null unique);

insert into regione(id_regione,nome)
values
(1,'italia'),
(2,'francia'),
(3,'spagna'),
(4,'germania'),
(5,'porto'),
(6,'ingl'),
(7,'svizzera'),
(8,'grecia'),
(9,'irlanda'),
(10,'malta');

select * from regione;


-- drop table vendite;
create table vendite (
id_vendite int primary key not null,
id_prodotto int not null ,
id_regione int not null,
prezzo decimal,
quantita int,
data_vendita date,
foreign key (id_prodotto) references prodotti(id_prodotto),
foreign key (id_regione) references regione(id_regione));


insert into vendite(id_vendite,id_prodotto,id_regione,prezzo,quantita,data_vendita) 
values(1,1,1,10,1,'2024-01-01'),
(2,2,1,15,1,'2024-10-01'),
(3,3,1,20,1,'2024-11-01'),
(4,4,1,18,1,'2023-03-01'),
(5,5,1,22,1,'2023-05-01'),
(6,6,1,25,1,'2024-01-01'),
(7,7,1,13,1,'2024-02-01'),
(8,8,1,8,1,'2024-08-01'),
(9,14,1,150,1,'2024-01-01'),
(10,15,1,130,1,'2024-12-01'),
(11,6,1,25,1,'2023-10-01'),
(12,7,1,13,1,'2023-07-01'),
(13,8,1,8,1,'2023-04-01'),
(14,14,1,150,1,'2023-01-01'),
(15,15,1,130,1,'2023-01-01'),
(16,2,1,15,1,'2024-06-01'),
(17,3,1,20,1,'2023-03-01'),
(18,4,1,18,1,'2023-08-01'),
(19,5,1,22,1,'2023-01-01'),
(20,2,2,15,1,'2024-07-01'),
(21,3,2,20,1,'2024-09-01'),
(22,4,2,18,1,'2024-09-01'),
(23,5,2,22,1,'2024-06-01'),
(24,6,2,25,1,'2024-12-01'),
(25,7,2,13,1,'2023-04-01'),
(26,8,2,8,1,'2024-05-01'),
(27,14,2,150,1,'2024-01-01'),
(28,15,3,130,1,'2024-01-01'),
(29,2,3,15,1,'2024-01-01'),
(30,3,3,20,1,'2024-01-01'),
(31,4,3,18,1,'2024-01-01'),
(32,5,3,22,1,'2024-07-01'),
(33,2,3,15,1,'2024-07-01'),
(34,5,4,22,1,'2024-01-01'),
(35,2,4,15,1,'2024-09-01'),
(36,3,4,20,1,'2024-01-01'),
(37,4,4,18,1,'2024-11-01'),
(38,5,4,22,1,'2023-01-01'),
(39,2,5,15,1,'2024-12-01'),
(40,3,5,20,1,'2024-02-01'),
(41,4,5,18,1,'2024-02-01'),
(42,5,5,22,1,'2023-01-01'),
(43,6,5,25,1,'2023-09-01'),
(44,4,6,18,1,'2024-01-01'),
(45,5,6,22,1,'2024-03-01'),
(46,6,6,25,1,'2024-07-01'),
(47,7,6,13,1,'2024-01-01'),
(48,8,6,8,1,'2024-05-01'),
(49,14,6,150,1,'2024-05-01'),
(50,2,7,15,1,'2024-05-01'),
(51,3,7,20,1,'2024-01-01'),
(52,4,7,18,1,'2024-01-01'),
(53,5,7,22,1,'2023-03-01'),
(54,5,8,22,1,'2024-03-01'),
(55,6,8,25,1,'2024-07-01'),
(56,7,8,13,1,'2024-12-01'),
(57,3,9,20,1,'2023-01-01'),
(58,4,9,18,1,'2024-01-01'),
(59,5,9,22,1,'2024-12-01'),
(60,6,9,25,1,'2024-11-01'),
(61,7,10,13,1,'2024-01-01'),
(62,8,10,8,1,'2024-12-01'),
(63,14,10,150,1,'2024-01-01'),
(64,15,10,130,1,'2024-11-01');

select * from vendite;


/*1. Verificare che i campi definiti come PK siano univoci. 
2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
  3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
  4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
  5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
 */
 -- 1. Verificare che i campi definiti come PK siano univoci. 
 select * from regione;
 select * from vendite;
 select * from prodotti;
 
 show columns from regione;
 show columns from vendite;
 show columns from prodotti;

 
 -- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
 select distinct prodotti.nome, sum(vendite.prezzo ) as fatturato , year(data_vendita) as anno
 from vendite join prodotti on vendite.id_prodotto = prodotti.id_prodotto
 group by anno,prodotti.nome;
 
 -- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
 select regione.nome, year(data_vendita) as anno ,sum(vendite.prezzo) as fatturato
 from regione join vendite on regione.id_regione = vendite.id_regione
 group by regione.nome,anno
 order by anno,fatturato desc;
 
 
 -- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
 
 select prodotti.categoria,sum(vendite.quantita) as q from prodotti join vendite on prodotti.id_prodotto = vendite.id_prodotto
 group by prodotti.categoria
 order by q desc
 limit 1;
 
 --   5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
 
 select * from prodotti where prodotti.nome not in( select prodotti.nome from prodotti
 join vendite on prodotti.id_prodotto = vendite.id_prodotto);
 
 select * from prodotti left join vendite on prodotti.id_prodotto = vendite.id_prodotto
 where vendite.id_prodotto is null;
 
 
 -- 6 Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
 select   prodotti.nome,  max(vendite.data_vendita) as ultima_vendita from prodotti join vendite on prodotti.id_prodotto = vendite.id_prodotto
 group by prodotti.nome;



 
 

